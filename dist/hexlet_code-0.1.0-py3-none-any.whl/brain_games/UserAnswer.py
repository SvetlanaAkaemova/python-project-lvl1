import prompt

random_number = random.randint(1, 30)
        print(f'Question: {random_number}')
        user_answer = prompt.string('Your answer: ')
        correct_answer = is_even_number()



