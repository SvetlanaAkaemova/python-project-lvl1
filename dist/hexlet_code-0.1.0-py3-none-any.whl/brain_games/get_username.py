import prompt


user_name = prompt.string('May I have your name? ')


def username():
    print(f'Hello, {user_name}!')
