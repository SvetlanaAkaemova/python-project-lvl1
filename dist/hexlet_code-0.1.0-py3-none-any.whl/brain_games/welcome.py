def welcome_to():
    print('Welcome to the Brain Games!')
